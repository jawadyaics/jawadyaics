// Main JavaScript file for Jawad Yaics Portfolio

// Mobile menu toggle functionality
function toggleMobileMenu() {
    const navLinks = document.getElementById('navLinks');
    navLinks.classList.toggle('active');
}

// Close mobile menu when clicking on a link
document.addEventListener('DOMContentLoaded', function() {
    const navLinks = document.querySelectorAll('.nav-links a');
    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            const navLinksContainer = document.getElementById('navLinks');
            navLinksContainer.classList.remove('active');
        });
    });
});

// Smooth scrolling for anchor links
document.addEventListener('DOMContentLoaded', function() {
    const links = document.querySelectorAll('a[href^="#"]');
    links.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href').substring(1);
            const targetElement = document.getElementById(targetId);
            if (targetElement) {
                targetElement.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
});

// Intersection Observer for fade-in animations
document.addEventListener('DOMContentLoaded', function() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);

    // Observe all fade-in elements
    const fadeElements = document.querySelectorAll('.fade-in, .fade-in-delay-1, .fade-in-delay-2, .fade-in-delay-3');
    fadeElements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
        el.style.transition = 'opacity 0.6s ease-out, transform 0.6s ease-out';
        observer.observe(el);
    });
});

// Progress bar animation
function animateProgressBars() {
    const progressBars = document.querySelectorAll('.progress-fill');
    progressBars.forEach(bar => {
        const width = bar.getAttribute('data-width') || '0%';
        setTimeout(() => {
            bar.style.width = width;
        }, 500);
    });
}

// Call progress bar animation when page loads
document.addEventListener('DOMContentLoaded', animateProgressBars);

// Form validation and enhancement
document.addEventListener('DOMContentLoaded', function() {
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        const inputs = form.querySelectorAll('input, textarea');
        inputs.forEach(input => {
            // Add focus and blur effects
            input.addEventListener('focus', function() {
                this.parentElement.classList.add('focused');
            });
            
            input.addEventListener('blur', function() {
                if (!this.value) {
                    this.parentElement.classList.remove('focused');
                }
            });
            
            // Real-time validation
            input.addEventListener('input', function() {
                if (this.checkValidity()) {
                    this.classList.remove('invalid');
                    this.classList.add('valid');
                } else {
                    this.classList.remove('valid');
                    this.classList.add('invalid');
                }
            });
        });
    });
});

// Navbar scroll effect
document.addEventListener('DOMContentLoaded', function() {
    const navbar = document.querySelector('.navbar');
    let lastScrollTop = 0;
    
    window.addEventListener('scroll', function() {
        const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        
        if (scrollTop > 100) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
        
        // Hide/show navbar on scroll
        if (scrollTop > lastScrollTop && scrollTop > 200) {
            navbar.style.transform = 'translateY(-100%)';
        } else {
            navbar.style.transform = 'translateY(0)';
        }
        
        lastScrollTop = scrollTop;
    });
});

// Loading animation for buttons
document.addEventListener('DOMContentLoaded', function() {
    const buttons = document.querySelectorAll('.btn');
    buttons.forEach(button => {
        button.addEventListener('click', function(e) {
            // Add ripple effect
            const ripple = document.createElement('span');
            const rect = this.getBoundingClientRect();
            const size = Math.max(rect.width, rect.height);
            const x = e.clientX - rect.left - size / 2;
            const y = e.clientY - rect.top - size / 2;
            
            ripple.style.width = ripple.style.height = size + 'px';
            ripple.style.left = x + 'px';
            ripple.style.top = y + 'px';
            ripple.classList.add('ripple');
            
            this.appendChild(ripple);
            
            setTimeout(() => {
                ripple.remove();
            }, 600);
        });
    });
});

// Lazy loading for images
document.addEventListener('DOMContentLoaded', function() {
    const images = document.querySelectorAll('img[data-src]');
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.classList.remove('lazy');
                imageObserver.unobserve(img);
            }
        });
    });
    
    images.forEach(img => imageObserver.observe(img));
});

// Copy to clipboard functionality
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(function() {
        // Show success message
        showNotification('Copied to clipboard!', 'success');
    }, function(err) {
        console.error('Could not copy text: ', err);
        showNotification('Failed to copy', 'error');
    });
}

// Notification system
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 12px 24px;
        border-radius: 8px;
        color: white;
        font-weight: 500;
        z-index: 10000;
        transform: translateX(100%);
        transition: transform 0.3s ease;
    `;
    
    if (type === 'success') {
        notification.style.backgroundColor = '#10B981';
    } else if (type === 'error') {
        notification.style.backgroundColor = '#EF4444';
    } else {
        notification.style.backgroundColor = '#3B82F6';
    }
    
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
    }, 100);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, 3000);
}

// Keyboard navigation
document.addEventListener('keydown', function(e) {
    // ESC key closes mobile menu
    if (e.key === 'Escape') {
        const navLinks = document.getElementById('navLinks');
        if (navLinks && navLinks.classList.contains('active')) {
            navLinks.classList.remove('active');
        }
    }
});

// Performance optimization: Debounce scroll events
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Optimized scroll handler
const optimizedScrollHandler = debounce(function() {
    // Add any scroll-based functionality here
}, 16); // ~60fps

window.addEventListener('scroll', optimizedScrollHandler);

// Theme detection and handling
document.addEventListener('DOMContentLoaded', function() {
    // Detect user's preferred color scheme
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    
    // Listen for changes in color scheme preference
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', e => {
        // Handle theme change if needed
    });
});

// Error handling for external resources
window.addEventListener('error', function(e) {
    if (e.target.tagName === 'IMG') {
        // Handle image loading errors
        e.target.style.display = 'none';
    }
});

// Service Worker registration (for PWA capabilities)
if ('serviceWorker' in navigator) {
    window.addEventListener('load', function() {
        // Uncomment when you have a service worker
        // navigator.serviceWorker.register('/sw.js')
        //     .then(function(registration) {
        //         console.log('SW registered: ', registration);
        //     })
        //     .catch(function(registrationError) {
        //         console.log('SW registration failed: ', registrationError);
        //     });
    });
}

// Analytics and tracking (placeholder)
function trackEvent(eventName, properties = {}) {
    // Add your analytics tracking code here
    console.log('Event tracked:', eventName, properties);
}

// Track page views
document.addEventListener('DOMContentLoaded', function() {
    trackEvent('page_view', {
        page: window.location.pathname,
        title: document.title
    });
});

// Export functions for use in other scripts
window.portfolioUtils = {
    toggleMobileMenu,
    copyToClipboard,
    showNotification,
    trackEvent,
    debounce
};

/* JAVASCRIPT FIXES - 29-07-2025 Adding these files for fixing issues of menu on mobile and buttons opening wide and removing white faded white squares below social links  */

// Enhanced mobile menu toggle functionality with auto-close
function toggleMobileMenu() {
    const navLinks = document.getElementById('navLinks');
    const menuButton = document.querySelector('.mobile-menu-toggle');
    const overlay = document.querySelector('.nav-overlay') || createOverlay();
    
    if (navLinks.classList.contains('active')) {
        closeMobileMenu();
    } else {
        openMobileMenu();
    }
}

function openMobileMenu() {
    const navLinks = document.getElementById('navLinks');
    const menuButton = document.querySelector('.mobile-menu-toggle');
    const overlay = document.querySelector('.nav-overlay') || createOverlay();
    
    navLinks.classList.add('active');
    menuButton.classList.add('active');
    overlay.classList.add('active');
    document.body.style.overflow = 'hidden'; // Prevent background scrolling
}

function closeMobileMenu() {
    const navLinks = document.getElementById('navLinks');
    const menuButton = document.querySelector('.mobile-menu-toggle');
    const overlay = document.querySelector('.nav-overlay');
    
    navLinks.classList.remove('active');
    menuButton.classList.remove('active');
    if (overlay) overlay.classList.remove('active');
    document.body.style.overflow = ''; // Restore scrolling
}

// Create overlay element if it doesn't exist
function createOverlay() {
    const overlay = document.createElement('div');
    overlay.className = 'nav-overlay';
    document.body.appendChild(overlay);
    
    // Close menu when overlay is clicked
    overlay.addEventListener('click', closeMobileMenu);
    
    return overlay;
}

// Auto-close menu on scroll
let scrollTimeout;
function handleScroll() {
    const navLinks = document.getElementById('navLinks');
    
    if (navLinks && navLinks.classList.contains('active')) {
        // Clear existing timeout
        clearTimeout(scrollTimeout);
        
        // Set a small delay to avoid closing on minor scrolls
        scrollTimeout = setTimeout(() => {
            closeMobileMenu();
        }, 100);
    }
}

// Auto-close menu when clicking outside
function handleClickOutside(event) {
    const navLinks = document.getElementById('navLinks');
    const menuButton = document.querySelector('.mobile-menu-toggle');
    
    if (navLinks && navLinks.classList.contains('active')) {
        // Check if click is outside menu and menu button
        if (!navLinks.contains(event.target) && !menuButton.contains(event.target)) {
            closeMobileMenu();
        }
    }
}

// Prevent button expansion and add proper click effects
function handleButtonClick(event) {
    const button = event.currentTarget;
    
    // Prevent default expansion
    event.preventDefault();
    
    // Add click effect
    button.style.transform = 'scale(0.98)';
    button.style.transition = 'transform 0.1s ease';
    
    // Reset after animation
    setTimeout(() => {
        button.style.transform = '';
        button.style.transition = '';
    }, 100);
    
    // Continue with original click behavior after a short delay
    setTimeout(() => {
        if (button.onclick && typeof button.onclick === 'function') {
            button.onclick(event);
        } else if (button.href) {
            window.location.href = button.href;
        } else if (button.type === 'submit') {
            button.closest('form')?.submit();
        }
    }, 50);
}

// Enhanced initialization
document.addEventListener('DOMContentLoaded', function() {
    // Create overlay if it doesn't exist
    if (!document.querySelector('.nav-overlay')) {
        createOverlay();
    }
    
    // Add scroll listener for auto-close
    window.addEventListener('scroll', handleScroll, { passive: true });
    
    // Add click outside listener
    document.addEventListener('click', handleClickOutside);
    
    // Add escape key listener
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closeMobileMenu();
        }
    });
    
    // Fix button click expansion for all buttons
    const buttons = document.querySelectorAll('.btn, button, input[type="submit"], input[type="button"]');
    buttons.forEach(button => {
        // Remove existing click handlers that might cause expansion
        button.addEventListener('mousedown', function(e) {
            e.preventDefault();
        });
        
        button.addEventListener('click', function(e) {
            // Add subtle scale effect instead of expansion
            this.style.transform = 'scale(0.98)';
            setTimeout(() => {
                this.style.transform = '';
            }, 150);
        });
    });
    
    // Close mobile menu when clicking on nav links
    const navLinks = document.querySelectorAll('.nav-links a');
    navLinks.forEach(link => {
        link.addEventListener('click', function() {
            // Small delay to allow navigation to start
            setTimeout(closeMobileMenu, 100);
        });
    });
    
    // Improve mobile menu button behavior
    const menuButton = document.querySelector('.mobile-menu-toggle');
    if (menuButton) {
        // Remove any existing click handlers
        menuButton.replaceWith(menuButton.cloneNode(true));
        
        // Add new click handler
        const newMenuButton = document.querySelector('.mobile-menu-toggle');
        newMenuButton.addEventListener('click', function(e) {
            e.stopPropagation();
            toggleMobileMenu();
        });
    }
});

// Handle window resize to close menu if switching to desktop
window.addEventListener('resize', function() {
    if (window.innerWidth >= 768) {
        closeMobileMenu();
    }
});

// Prevent menu from staying open when page visibility changes
document.addEventListener('visibilitychange', function() {
    if (document.hidden) {
        closeMobileMenu();
    }
});

// Enhanced ripple effect that doesn't cause expansion
function addRippleEffect(button) {
    button.addEventListener('click', function(e) {
        const ripple = document.createElement('span');
        const rect = this.getBoundingClientRect();
        const size = Math.max(rect.width, rect.height);
        const x = e.clientX - rect.left - size / 2;
        const y = e.clientY - rect.top - size / 2;
        
        ripple.style.width = ripple.style.height = size + 'px';
        ripple.style.left = x + 'px';
        ripple.style.top = y + 'px';
        ripple.classList.add('ripple');
        
        // Ensure button doesn't expand
        this.style.position = 'relative';
        this.style.overflow = 'hidden';
        
        this.appendChild(ripple);
        
        setTimeout(() => {
            ripple.remove();
        }, 600);
    });
}

// Apply ripple effect to buttons without causing expansion
document.addEventListener('DOMContentLoaded', function() {
    const rippleButtons = document.querySelectorAll('.btn');
    rippleButtons.forEach(addRippleEffect);
});

// Fix any existing event listeners that might cause issues
function fixExistingEventListeners() {
    // Remove problematic event listeners and replace with fixed ones
    const problematicButtons = document.querySelectorAll('button, .btn');
    
    problematicButtons.forEach(button => {
        // Clone to remove all event listeners
        const newButton = button.cloneNode(true);
        button.parentNode.replaceChild(newButton, button);
        
        // Add proper click handler
        newButton.addEventListener('click', function(e) {
            // Prevent expansion
            this.style.transform = 'scale(0.98)';
            setTimeout(() => {
                this.style.transform = '';
            }, 100);
        });
    });
}

// Call fix function after DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    setTimeout(fixExistingEventListeners, 100);
});


/* ENHANCED FUNCTIONALITY - 29-07-2025 Adding these files */

// Enhanced filter button functionality with smooth scrolling
document.addEventListener('DOMContentLoaded', function() {
    initializeFilterButtons();
    initializeHeaderFunctionality();
});

function initializeFilterButtons() {
    // Wrap existing filter buttons in scrollable container
    const filterSections = document.querySelectorAll('.container-highlight-blue, .container-primary-blue, .container-rich-beige');
    
    filterSections.forEach(section => {
        const flexContainer = section.querySelector('.flex.gap-2.flex-wrap.justify-center');
        if (flexContainer) {
            // Create wrapper and container
            const wrapper = document.createElement('div');
            wrapper.className = 'filter-buttons-wrapper';
            
            const container = document.createElement('div');
            container.className = 'filter-buttons-container';
            
            // Move all buttons to the new container
            const buttons = Array.from(flexContainer.children);
            buttons.forEach(button => {
                container.appendChild(button);
            });
            
            // Replace the old container
            wrapper.appendChild(container);
            flexContainer.parentNode.replaceChild(wrapper, flexContainer);
            
            // Add smooth scrolling functionality
            addFilterScrollFunctionality(container);
        }
    });
}

function addFilterScrollFunctionality(container) {
    let isScrolling = false;
    
    // Add smooth scroll behavior for button clicks
    const buttons = container.querySelectorAll('.btn');
    buttons.forEach((button, index) => {
        button.addEventListener('click', function(e) {
            // Scroll the clicked button into view on mobile
            if (window.innerWidth < 768) {
                setTimeout(() => {
                    this.scrollIntoView({
                        behavior: 'smooth',
                        block: 'nearest',
                        inline: 'center'
                    });
                }, 100);
            }
            
            // Update active state
            buttons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
        });
    });
    
    // Add touch/swipe support for mobile
    if (window.innerWidth < 768) {
        let startX = 0;
        let scrollLeft = 0;
        
        container.addEventListener('touchstart', function(e) {
            startX = e.touches[0].pageX - container.offsetLeft;
            scrollLeft = container.scrollLeft;
        }, { passive: true });
        
        container.addEventListener('touchmove', function(e) {
            if (!startX) return;
            
            const x = e.touches[0].pageX - container.offsetLeft;
            const walk = (x - startX) * 2;
            container.scrollLeft = scrollLeft - walk;
        }, { passive: true });
        
        container.addEventListener('touchend', function() {
            startX = 0;
        });
    }
    
    // Add keyboard navigation
    container.addEventListener('keydown', function(e) {
        const activeButton = container.querySelector('.btn.active') || container.querySelector('.btn');
        const buttons = Array.from(container.querySelectorAll('.btn'));
        const currentIndex = buttons.indexOf(activeButton);
        
        let newIndex = currentIndex;
        
        switch(e.key) {
            case 'ArrowLeft':
                newIndex = Math.max(0, currentIndex - 1);
                break;
            case 'ArrowRight':
                newIndex = Math.min(buttons.length - 1, currentIndex + 1);
                break;
            case 'Home':
                newIndex = 0;
                break;
            case 'End':
                newIndex = buttons.length - 1;
                break;
            default:
                return;
        }
        
        e.preventDefault();
        buttons[newIndex].focus();
        buttons[newIndex].click();
    });
}

function initializeHeaderFunctionality() {
    const navbar = document.querySelector('.navbar');
    if (!navbar) return;
    
    // Ensure header is always visible
    navbar.style.display = 'block';
    navbar.style.visibility = 'visible';
    navbar.style.opacity = '1';
    
    // Enhanced scroll behavior
    let lastScrollTop = 0;
    let scrollTimeout;
    
    window.addEventListener('scroll', function() {
        clearTimeout(scrollTimeout);
        
        scrollTimeout = setTimeout(() => {
            const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
            
            // Add scrolled class for styling
            if (scrollTop > 50) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
            
            // On mobile, hide/show navbar based on scroll direction
            if (window.innerWidth < 768) {
                if (scrollTop > lastScrollTop && scrollTop > 100) {
                    // Scrolling down
                    navbar.style.transform = 'translateY(-100%)';
                } else {
                    // Scrolling up
                    navbar.style.transform = 'translateY(0)';
                }
            } else {
                // Always show on desktop
                navbar.style.transform = 'translateY(0)';
            }
            
            lastScrollTop = scrollTop;
        }, 10);
    }, { passive: true });
    
    // Handle window resize
    window.addEventListener('resize', function() {
        // Reset navbar position on resize
        if (window.innerWidth >= 768) {
            navbar.style.transform = 'translateY(0)';
        }
        
        // Reinitialize filter buttons if needed
        setTimeout(initializeFilterButtons, 100);
    });
}

// Enhanced mobile menu functionality
function enhancedToggleMobileMenu() {
    const navLinks = document.getElementById('navLinks');
    const menuButton = document.querySelector('.mobile-menu-toggle');
    
    if (!navLinks || !menuButton) return;
    
    if (navLinks.classList.contains('active')) {
        // Close menu
        navLinks.classList.remove('active');
        menuButton.classList.remove('active');
        document.body.style.overflow = '';
    } else {
        // Open menu
        navLinks.classList.add('active');
        menuButton.classList.add('active');
        document.body.style.overflow = 'hidden';
    }
}

// Replace the existing toggleMobileMenu function
window.toggleMobileMenu = enhancedToggleMobileMenu;

// Smooth scrolling for anchor links
function initializeSmoothScrolling() {
    const links = document.querySelectorAll('a[href^="#"]');
    
    links.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href').substring(1);
            const targetElement = document.getElementById(targetId);
            
            if (targetElement) {
                const headerHeight = document.querySelector('.navbar')?.offsetHeight || 0;
                const targetPosition = targetElement.offsetTop - headerHeight - 20;
                
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });
}

// Initialize smooth scrolling
document.addEventListener('DOMContentLoaded', initializeSmoothScrolling);

// Filter button animation enhancement
function enhanceFilterButtons() {
    const filterButtons = document.querySelectorAll('.filter-buttons-container .btn');
    
    filterButtons.forEach(button => {
        button.addEventListener('mouseenter', function() {
            if (window.innerWidth >= 768) {
                this.style.transform = 'translateY(-2px)';
            }
        });
        
        button.addEventListener('mouseleave', function() {
            if (window.innerWidth >= 768) {
                this.style.transform = '';
            }
        });
        
        button.addEventListener('focus', function() {
            this.style.outline = '2px solid var(--primary-blue)';
            this.style.outlineOffset = '2px';
        });
        
        button.addEventListener('blur', function() {
            this.style.outline = '';
            this.style.outlineOffset = '';
        });
    });
}

// Initialize enhanced filter buttons
document.addEventListener('DOMContentLoaded', function() {
    setTimeout(enhanceFilterButtons, 500);
});

// Accessibility improvements
function initializeAccessibility() {
    // Add ARIA labels to filter buttons
    const filterContainers = document.querySelectorAll('.filter-buttons-container');
    filterContainers.forEach(container => {
        container.setAttribute('role', 'tablist');
        container.setAttribute('aria-label', 'Filter options');
        
        const buttons = container.querySelectorAll('.btn');
        buttons.forEach((button, index) => {
            button.setAttribute('role', 'tab');
            button.setAttribute('aria-selected', button.classList.contains('active') ? 'true' : 'false');
            button.setAttribute('tabindex', index === 0 ? '0' : '-1');
        });
    });
    
    // Add skip link for keyboard users
    const skipLink = document.createElement('a');
    skipLink.href = '#main-content';
    skipLink.textContent = 'Skip to main content';
    skipLink.className = 'skip-link';
    skipLink.style.cssText = `
        position: absolute;
        top: -40px;
        left: 6px;
        background: var(--primary-blue);
        color: white;
        padding: 8px;
        text-decoration: none;
        border-radius: 4px;
        z-index: 10000;
        transition: top 0.3s;
    `;
   
    skipLink.addEventListener('focus', function() {
        this.style.top = '6px';
    });
   
    skipLink.addEventListener('blur', function() {
        this.style.top = '-40px';
    });
   
    document.body.insertBefore(skipLink, document.body.firstChild);
}


// Initialize accessibility features
document.addEventListener('DOMContentLoaded', initializeAccessibility);

// Performance optimization for scroll events
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Apply debouncing to scroll-heavy functions
const debouncedScrollHandler = debounce(function() {
    // Any additional scroll handling can go here
}, 16);

window.addEventListener('scroll', debouncedScrollHandler, { passive: true });



/* PHOTO GALLERY JAVASCRIPT - Added these files on 30-7-2025 */

// Photo Gallery Functionality
class PhotoGallery {
    constructor() {
        this.gallery = document.getElementById('photoGallery');
        this.prevBtn = document.getElementById('galleryPrev');
        this.nextBtn = document.getElementById('galleryNext');
        this.indicators = document.getElementById('galleryIndicators');
        this.currentSlide = 0;
        this.totalSlides = 0;
        this.slideWidth = 0;
        this.isScrolling = false;
        
        if (this.gallery) {
            this.init();
        }
    }
    
    init() {
        this.setupGallery();
        this.bindEvents();
        this.updateNavigation();
        this.setupIntersectionObserver();
        this.setupKeyboardNavigation();
        this.setupTouchNavigation();
    }
    
    setupGallery() {
        const items = this.gallery.querySelectorAll('.gallery-item');
        this.totalSlides = items.length;
        
        // Calculate slide width including gap
        if (items.length > 0) {
            const firstItem = items[0];
            const computedStyle = window.getComputedStyle(firstItem);
            this.slideWidth = firstItem.offsetWidth + parseInt(computedStyle.marginRight || 0);
        }
        
        // Set initial scroll position
        this.gallery.scrollLeft = 0;
    }
    
    bindEvents() {
        // Navigation buttons
        if (this.prevBtn) {
            this.prevBtn.addEventListener('click', () => this.previousSlide());
        }
        
        if (this.nextBtn) {
            this.nextBtn.addEventListener('click', () => this.nextSlide());
        }
        
        // Indicator buttons
        if (this.indicators) {
            const indicatorBtns = this.indicators.querySelectorAll('.indicator');
            indicatorBtns.forEach((btn, index) => {
                btn.addEventListener('click', () => this.goToSlide(index));
            });
        }
        
        // Scroll event for updating indicators
        this.gallery.addEventListener('scroll', this.debounce(() => {
            this.updateCurrentSlide();
            this.updateIndicators();
        }, 100));
        
        // Window resize
        window.addEventListener('resize', this.debounce(() => {
            this.setupGallery();
            this.updateNavigation();
        }, 250));
    }
    
    setupIntersectionObserver() {
        // Lazy loading and animation triggers
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const item = entry.target;
                    item.classList.add('visible');
                    
                    // Load images if they have data-src
                    const img = item.querySelector('img[data-src]');
                    if (img) {
                        img.src = img.dataset.src;
                        img.removeAttribute('data-src');
                    }
                }
            });
        }, {
            threshold: 0.1,
            rootMargin: '50px'
        });
        
        const items = this.gallery.querySelectorAll('.gallery-item');
        items.forEach(item => observer.observe(item));
    }
    
    setupKeyboardNavigation() {
        document.addEventListener('keydown', (e) => {
            if (!this.gallery.matches(':hover') && !document.activeElement.closest('.photo-gallery-wrapper')) {
                return;
            }
            
            switch(e.key) {
                case 'ArrowLeft':
                    e.preventDefault();
                    this.previousSlide();
                    break;
                case 'ArrowRight':
                    e.preventDefault();
                    this.nextSlide();
                    break;
                case 'Home':
                    e.preventDefault();
                    this.goToSlide(0);
                    break;
                case 'End':
                    e.preventDefault();
                    this.goToSlide(this.totalSlides - 1);
                    break;
            }
        });
    }
    
    setupTouchNavigation() {
        let startX = 0;
        let startY = 0;
        let startScrollLeft = 0;
        let isDragging = false;
        
        this.gallery.addEventListener('touchstart', (e) => {
            startX = e.touches[0].pageX;
            startY = e.touches[0].pageY;
            startScrollLeft = this.gallery.scrollLeft;
            isDragging = true;
        }, { passive: true });
        
        this.gallery.addEventListener('touchmove', (e) => {
            if (!isDragging) return;
            
            const x = e.touches[0].pageX;
            const y = e.touches[0].pageY;
            const walkX = (x - startX) * 2;
            const walkY = Math.abs(y - startY);
            
            // Only scroll horizontally if horizontal movement is greater
            if (Math.abs(walkX) > walkY) {
                e.preventDefault();
                this.gallery.scrollLeft = startScrollLeft - walkX;
            }
        }, { passive: false });
        
        this.gallery.addEventListener('touchend', () => {
            isDragging = false;
            this.snapToNearestSlide();
        });
        
        // Mouse drag support for desktop
        let isMouseDown = false;
        let mouseStartX = 0;
        let mouseStartScrollLeft = 0;
        
        this.gallery.addEventListener('mousedown', (e) => {
            isMouseDown = true;
            mouseStartX = e.pageX;
            mouseStartScrollLeft = this.gallery.scrollLeft;
            this.gallery.style.cursor = 'grabbing';
            e.preventDefault();
        });
        
        this.gallery.addEventListener('mousemove', (e) => {
            if (!isMouseDown) return;
            
            const x = e.pageX;
            const walk = (x - mouseStartX) * 2;
            this.gallery.scrollLeft = mouseStartScrollLeft - walk;
        });
        
        this.gallery.addEventListener('mouseup', () => {
            isMouseDown = false;
            this.gallery.style.cursor = 'grab';
            this.snapToNearestSlide();
        });
        
        this.gallery.addEventListener('mouseleave', () => {
            isMouseDown = false;
            this.gallery.style.cursor = 'grab';
        });
    }
    
    previousSlide() {
        if (this.isScrolling) return;
        
        const newSlide = Math.max(0, this.currentSlide - 1);
        this.goToSlide(newSlide);
    }
    
    nextSlide() {
        if (this.isScrolling) return;
        
        const newSlide = Math.min(this.totalSlides - 1, this.currentSlide + 1);
        this.goToSlide(newSlide);
    }
    
    goToSlide(slideIndex) {
        if (this.isScrolling || slideIndex < 0 || slideIndex >= this.totalSlides) return;
        
        this.isScrolling = true;
        this.currentSlide = slideIndex;
        
        const targetScrollLeft = slideIndex * this.slideWidth;
        this.smoothScrollTo(targetScrollLeft);
        
        this.updateIndicators();
        this.updateNavigation();
        
        // Reset scrolling flag after animation
        setTimeout(() => {
            this.isScrolling = false;
        }, 500);
    }
    
    smoothScrollTo(targetScrollLeft) {
        const startScrollLeft = this.gallery.scrollLeft;
        const distance = targetScrollLeft - startScrollLeft;
        const duration = 400;
        let startTime = null;
        
        const animateScroll = (currentTime) => {
            if (startTime === null) startTime = currentTime;
            const timeElapsed = currentTime - startTime;
            const progress = Math.min(timeElapsed / duration, 1);
            
            // Easing function (ease-out)
            const easeOut = 1 - Math.pow(1 - progress, 3);
            
            this.gallery.scrollLeft = startScrollLeft + (distance * easeOut);
            
            if (progress < 1) {
                requestAnimationFrame(animateScroll);
            }
        };
        
        requestAnimationFrame(animateScroll);
    }
    
    snapToNearestSlide() {
        const scrollLeft = this.gallery.scrollLeft;
        const slideIndex = Math.round(scrollLeft / this.slideWidth);
        this.goToSlide(slideIndex);
    }
    
    updateCurrentSlide() {
        const scrollLeft = this.gallery.scrollLeft;
        this.currentSlide = Math.round(scrollLeft / this.slideWidth);
    }
    
    updateIndicators() {
        if (!this.indicators) return;
        
        const indicatorBtns = this.indicators.querySelectorAll('.indicator');
        indicatorBtns.forEach((btn, index) => {
            btn.classList.toggle('active', index === this.currentSlide);
        });
    }
    
    updateNavigation() {
        if (this.prevBtn) {
            this.prevBtn.style.opacity = this.currentSlide === 0 ? '0.5' : '1';
            this.prevBtn.disabled = this.currentSlide === 0;
        }
        
        if (this.nextBtn) {
            this.nextBtn.style.opacity = this.currentSlide === this.totalSlides - 1 ? '0.5' : '1';
            this.nextBtn.disabled = this.currentSlide === this.totalSlides - 1;
        }
    }
    
    // Auto-play functionality (optional)
    startAutoPlay(interval = 5000) {
        this.stopAutoPlay();
        this.autoPlayInterval = setInterval(() => {
            if (this.currentSlide === this.totalSlides - 1) {
                this.goToSlide(0);
            } else {
                this.nextSlide();
            }
        }, interval);
    }
    
    stopAutoPlay() {
        if (this.autoPlayInterval) {
            clearInterval(this.autoPlayInterval);
            this.autoPlayInterval = null;
        }
    }
    
    // Utility function for debouncing
    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
}

// Enhanced Filter Buttons Functionality
function initializeEnhancedFilterButtons() {
    const filterContainers = document.querySelectorAll('.filter-buttons-container');
    
    filterContainers.forEach(container => {
        const buttons = container.querySelectorAll('.btn');
        
        // Add smooth scrolling when button is clicked
        buttons.forEach((button, index) => {
            button.addEventListener('click', function(e) {
                // Scroll the clicked button into view
                setTimeout(() => {
                    this.scrollIntoView({
                        behavior: 'smooth',
                        block: 'nearest',
                        inline: 'center'
                    });
                }, 100);
                
                // Update active state
                buttons.forEach(btn => btn.classList.remove('active'));
                this.classList.add('active');
            });
        });
        
        // Add keyboard navigation
        container.addEventListener('keydown', function(e) {
            const activeButton = container.querySelector('.btn.active') || container.querySelector('.btn');
            const buttonArray = Array.from(buttons);
            const currentIndex = buttonArray.indexOf(activeButton);
            
            let newIndex = currentIndex;
            
            switch(e.key) {
                case 'ArrowLeft':
                    newIndex = Math.max(0, currentIndex - 1);
                    break;
                case 'ArrowRight':
                    newIndex = Math.min(buttons.length - 1, currentIndex + 1);
                    break;
                case 'Home':
                    newIndex = 0;
                    break;
                case 'End':
                    newIndex = buttons.length - 1;
                    break;
                default:
                    return;
            }
            
            e.preventDefault();
            buttons[newIndex].focus();
            buttons[newIndex].click();
        });
    });
}

// Initialize everything when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize photo gallery
    const photoGallery = new PhotoGallery();
    
    // Initialize enhanced filter buttons
    initializeEnhancedFilterButtons();
    
    // Optional: Start auto-play for gallery (uncomment if desired)
    // photoGallery.startAutoPlay(6000);
    
    // Pause auto-play when user interacts with gallery
    const galleryWrapper = document.querySelector('.photo-gallery-wrapper');
    if (galleryWrapper) {
        galleryWrapper.addEventListener('mouseenter', () => {
            if (photoGallery.autoPlayInterval) {
                photoGallery.stopAutoPlay();
            }
        });
        
        galleryWrapper.addEventListener('mouseleave', () => {
            // Optionally restart auto-play when mouse leaves
            // photoGallery.startAutoPlay(6000);
        });
    }
});

// Handle visibility change (pause when tab is not active)
document.addEventListener('visibilitychange', function() {
    const photoGallery = window.photoGallery;
    if (photoGallery) {
        if (document.hidden) {
            photoGallery.stopAutoPlay();
        }
    }
});

// Export for global access if needed
window.PhotoGallery = PhotoGallery;